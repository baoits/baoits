/**
Created by IntelliJ IDEA.
User: lichee
Date: 2019-01-17
Time: 11:28
To change this template use File | Settings | File Templates.
*/
DROP DATABASE IF EXISTS db_tmall_j2ee;
CREATE DATABASE db_tmall_j2ee DEFAULT CHARACTER SET utf8;
USE db_tmall_j2ee;

-- 分类表
DROP TABLE IF EXISTS tb_category;
CREATE TABLE tb_category (
                           id INT (11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '分类ID',
                           name VARCHAR (255) DEFAULT NULL COMMENT '分类名称'
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- 用户表
DROP TABLE IF EXISTS tb_user;
CREATE TABLE tb_user (
                       id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '用户ID',
                       name VARCHAR(255) DEFAULT NULL COMMENT '用户账号',
                       password VARCHAR(255) DEFAULT NULL COMMENT '用户密码'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户信息表';

-- 订单表
DROP TABLE IF EXISTS tb_order;
CREATE Table tb_order (
                        id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '订单ID',
                        orderCode VARCHAR(255) DEFAULT NULL COMMENT '订单号',
                        address VARCHAR(255) DEFAULT NULL COMMENT '收货地址',
                        post VARCHAR(255) DEFAULT NULL COMMENT '邮政编码',
                        receiver VARCHAR(255) DEFAULT NULL COMMENT '收货人信息',
                        mobile VARCHAR(255) DEFAULT NULL COMMENT '手机号码',
                        userMessage VARCHAR(255) DEFAULT NULL COMMENT '用户备注信息',
                        createDate DATETIME DEFAULT NULL COMMENT '订单创建日前',
                        payDate DATETIME DEFAULT NULL COMMENT '付款日期',
                        deliveryDate DATETIME DEFAULT NULL COMMENT '发货日期',
                        confirmDate DATETIME DEFAULT NULL COMMENT '确认收货日期',
                        uid INT(11) DEFAULT NULL COMMENT '[外键]用户ID',
                        status VARCHAR(255) DEFAULT NULL COMMENT '订单状态',
                        CONSTRAINT fk_order_user FOREIGN KEY (uid) REFERENCES tb_user (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单表';

-- 产品表
DROP TABLE IF EXISTS tb_product;
CREATE TABLE tb_product (
                          id INT (11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '产品ID',
                          name VARCHAR (255) DEFAULT NULL COMMENT '产品名称',
                          subTitle VARCHAR(255) DEFAULT NULL COMMENT '产品小标题',
                          orignalPrice DECIMAL(63,2) DEFAULT NULL COMMENT '原始价格',
                          promotePrice DECIMAL(63,2) DEFAULT NULL COMMENT '优惠价格',
                          stock INT (11) DEFAULT NULL COMMENT '产品库存',
                          cid INT(11) DEFAULT NULL COMMENT '[外键]分类ID',
                          createDate DATETIME DEFAULT NULL COMMENT '创建日期',
                          CONSTRAINT fk_product_category FOREIGN KEY (cid) REFERENCES tb_category (id)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='产品表';

-- 产品图片表
DROP TABLE IF EXISTS tb_productimage;
CREATE TABLE tb_productimage (
                               id INT (11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '图片ID',
                               pid INT(11) DEFAULT NULL COMMENT '[外键]产品ID',
                               type VARCHAR (255) DEFAULT NULL COMMENT '产品类型',
                               CONSTRAINT fk_productimage_product FOREIGN KEY (pid) REFERENCES tb_product (id)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='产品图片表';

-- 属性表
DROP TABLE IF EXISTS tb_property;
CREATE TABLE tb_property (
                           id INT (11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '分类名称',
                           cid INT(11) DEFAULT NULL  COMMENT '[外键]分类ID',
                           name VARCHAR (255) DEFAULT NULL  COMMENT '属性名称',
                           CONSTRAINT fk_property_category FOREIGN KEY (cid) REFERENCES tb_category (id)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='属性表';

-- 属性值表
DROP TABLE IF EXISTS tb_propertyvalue;
CREATE TABLE tb_propertyvalue (
                                id INT (11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '属性值ID',
                                pid INT(11) DEFAULT NULL COMMENT '[外键]产品ID',
                                ptid INT(11) DEFAULT NULL COMMENT '[外键]属性ID',
                                value VARCHAR (255) DEFAULT NULL COMMENT '属性的值',
                                CONSTRAINT fk_propertyvalue_property FOREIGN KEY (ptid) REFERENCES tb_property (id),
                                CONSTRAINT fk_propertyvalue_product FOREIGN KEY (pid) REFERENCES tb_product (id)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='属性值表';

-- 评价表
DROP TABLE IF EXISTS tb_review;
CREATE Table tb_review (
                         id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '评价ID',
                         content VARCHAR(4000) DEFAULT NULL COMMENT '评价内容',
                         uid INT(11) DEFAULT NULL COMMENT '[外键]评价者',
                         pid INT(11) DEFAULT NULL COMMENT '[外键]评价产品',
                         createDate DATETIME DEFAULT NULL COMMENT '评价时间',
                         CONSTRAINT fk_review_product FOREIGN KEY (pid) REFERENCES tb_product (id),
                         CONSTRAINT fk_review_user FOREIGN KEY (uid) REFERENCES tb_user (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='评价表';

-- 订单项表
DROP TABLE IF EXISTS tb_orderitem;
CREATE TABLE tb_orderitem (
                            id INT (11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '订单项ID',
                            pid INT (11) DEFAULT NULL COMMENT '[外键]产品ID',
                            oid INT (11) DEFAULT NULL COMMENT '[外键]订单ID',
                            uid INT (11) DEFAULT NULL COMMENT '[外键]用户ID',
                            number INT (11) DEFAULT NULL COMMENT '购买数量',
                            CONSTRAINT fk_orderitem_user FOREIGN KEY (uid) REFERENCES tb_user (id),
                            CONSTRAINT fk_orderitem_product FOREIGN KEY (pid) REFERENCES tb_product (id),
                            CONSTRAINT fk_orderitem_order FOREIGN KEY (oid) REFERENCES tb_order (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单项表';






