/**
 * Created by IntelliJ IDEA.
 * User: lichee
 * Date: 2019-01-17
 * Time: 11:28
 * To change this template use File | Settings | File Templates.
 */
package top.baoit.tmall.j2ee.util;

import java.sql.*;
import java.util.ResourceBundle;

public class DatabaseUtil {
    //服务器端  连接数据库工具类
    static ResourceBundle resourceBundle=null;
    static String url,driver,username,password;

    static{
        resourceBundle= ResourceBundle.getBundle("db");
        url=resourceBundle.getString("url");
        driver=resourceBundle.getString("driver");
        username=resourceBundle.getString("username");
        password=resourceBundle.getString("password");
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url,username,password);
    }

    public static void closeConnection(Connection connection, Statement Statement, ResultSet resultSet){
        try {
            if(connection!=null){
                connection.close();
            }
            if(Statement!=null){
                Statement.close();
            }
            if(resultSet!=null){
                resultSet.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
