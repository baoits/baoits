/**
 * Created by IntelliJ IDEA.
 * User: lichee
 * Date: 2019-01-17
 * Time: 11:28
 * To change this template use File | Settings | File Templates.
 */
package top.baoit.tmall.j2ee.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTimeUtil {
    public static Timestamp d2t(Date date) {
        if (null == date){
            return null;
        }
        return new Timestamp(date.getTime());
    }

    public Date t2d(Timestamp timestamp) {
        if (null == timestamp){
            return null;
        }
        return new Date(timestamp.getTime());
    }

    public static Timestamp getRegtime(String time){
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date=new Date();
        try {
            date=sdf.parse(time);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        Timestamp ts=new Timestamp(date.getTime());
        return ts;
    }

    //*Timestamp转String*//
    public static String gettime(Timestamp ts){
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Long longtime=ts.getTime();
        Date date=new Date(longtime);
        return sdf.format(date);
    }
}
