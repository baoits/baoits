package top.baoit.tmall.j2ee.util;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class DaoUtil {
    Connection connection;
    java.sql.Statement Statement;
    ResultSet resultSet;
    PreparedStatement preparedStatement;
    String objecttype,objectkey ;
    Object objectvalue;
    Boolean aBoolean;

    //添加方法
    public String insert(Object object,String sqlkey){
        try {
            String insertsql=GetSqlUtil.getSQL(sqlkey);
            connection=DatabaseUtil.getConnection();
            preparedStatement=connection.prepareStatement(insertsql,Statement.RETURN_GENERATED_KEYS);
            getObject(object);
            aBoolean=preparedStatement.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            DatabaseUtil.closeConnection(connection,preparedStatement,resultSet);
        }
        return aBoolean.toString();
    }

    private void getObject(Object object) throws IllegalAccessException, SQLException {
        Class objectClazz = (Class) object.getClass();
        Field[] fields=objectClazz.getDeclaredFields();
        for (int i=1;i<=fields.length;i++) {
            Field field = fields[i-1];
            field.setAccessible(true); // 设置些属性是可以访问的
            objecttype= field.getType().toString();// 得到此属性的类型
            objectkey = field.getName();// key:得到属性名
            objectvalue = field.get(object);// 得到此属性的值
            System.out.println(objecttype);

            if(objecttype.equals("class java.lang.String")){
                String key=objectvalue.toString();
                preparedStatement.setString(i,key);
            }
            if(objecttype.equals("class java.lang.Integer")){
                Integer key=Integer.parseInt(objectvalue.toString());
                preparedStatement.setInt(i,key);
            }
            if(objecttype.equals("class java.lang.Float")){

            }

            if(objecttype.equals("class java.lang.Short")){


            }

            if(objecttype.equals("class java.lang.Double")){

            }

            if(objecttype.equals("class java.util.Date")){

            }
            if(objecttype.equals("class java.lang.Object")){

            }
        }
    }
}
