/**
 * Created by IntelliJ IDEA.
 * User: lichee
 * Date: 2019-01-17
 * Time: 11:28
 * To change this template use File | Settings | File Templates.
 */
package top.baoit.tmall.j2ee.dao;

public interface UserDao {

}
