package top.baoit.tmall.j2ee.test;

import top.baoit.tmall.j2ee.pojo.OrderPojo;
import top.baoit.tmall.j2ee.pojo.ProductPojo;
import top.baoit.tmall.j2ee.pojo.UserPojo;
import top.baoit.tmall.j2ee.util.DaoUtil;
import top.baoit.tmall.j2ee.util.UserNameUtil;

public class Testing {
    public static void main(String[] args) {
        UserPojo userPojo=new UserPojo();
        userPojo.setId(3);
        userPojo.setPassword("4523");
        userPojo.setName("helloworld");
        //UserNameUtil.hideName(userPojo);
        DaoUtil daoUtil=new DaoUtil();
        daoUtil.insert(userPojo,"insert");
    }
}
