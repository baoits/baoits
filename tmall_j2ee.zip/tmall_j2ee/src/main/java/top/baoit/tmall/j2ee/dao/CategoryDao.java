/**
 * Created by IntelliJ IDEA.
 * User: lichee
 * Date: 2019-01-17
 * Time: 11:28
 * To change this template use File | Settings | File Templates.
 */
package top.baoit.tmall.j2ee.dao;

import top.baoit.tmall.j2ee.pojo.CategoryPojo;

import java.util.List;

public interface CategoryDao {
    public int getCount() ;//获取总数
    public int add(CategoryPojo categoryPojo);//增加
    public int update(CategoryPojo categoryPojo);//修改
    public int delete(Integer id);//删除
    public CategoryPojo findByID(Integer id);//按ID查询
    public List<CategoryPojo> list();//查询所以
    public List<CategoryPojo> list(Integer start, Integer count);//分页查询
}
