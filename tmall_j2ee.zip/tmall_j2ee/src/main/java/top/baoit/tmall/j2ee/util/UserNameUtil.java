package top.baoit.tmall.j2ee.util;

import top.baoit.tmall.j2ee.pojo.UserPojo;

public  class UserNameUtil {
    public static String hideName(UserPojo userPojo) {
        String result = null;
        String name = userPojo.getName();
        if (null == name || "" == name) {
            result = "该用户很神秘";
        }
        if (name.length() == 1) {
            result = "*";
        }
        if (name.length() == 2) {
            result = name.substring(0, 1) + "*";
        }
        if (name.length() > 2) {
            int methods = (int) Math.ceil(Math.random() * 2);
            if (methods == 1) {
                result = name.substring(0, 1);
                for (int i = 0; i < name.length() - 2; i++) {
                    result += "*";
                }
                result += name.substring(name.length() - 1, name.length());
            }

            if (methods == 2) {//经测试耗时比第一种方式短
                char[] cs = name.toCharArray();
                for (int i = 1; i < cs.length - 1; i++) {
                    cs[i] = '*';
                }
                result = new String(cs);
            }
        }
        System.out.println(result);
        return result;
    }
}
