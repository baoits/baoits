/**
 * Created by IntelliJ IDEA.
 * User: lichee
 * Date: 2019-01-17
 * Time: 11:28
 * To change this template use File | Settings | File Templates.
 */
package top.baoit.tmall.j2ee.pojo;

public class OrderItemPojo {
    private Integer number;
    private ProductPojo productPojo;
    private OrderPojo orderPojo;
    private UserPojo userPojo;
    private Integer id;

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public ProductPojo getProductPojo() {
        return productPojo;
    }

    public void setProductPojo(ProductPojo productPojo) {
        this.productPojo = productPojo;
    }

    public OrderPojo getOrderPojo() {
        return orderPojo;
    }

    public void setOrderPojo(OrderPojo orderPojo) {
        this.orderPojo = orderPojo;
    }

    public UserPojo getUserPojo() {
        return userPojo;
    }

    public void setUserPojo(UserPojo userPojo) {
        this.userPojo = userPojo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
