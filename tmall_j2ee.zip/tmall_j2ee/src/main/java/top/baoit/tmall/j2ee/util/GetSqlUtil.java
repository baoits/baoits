package top.baoit.tmall.j2ee.util;

import java.util.ResourceBundle;

public class GetSqlUtil {
    //服务器端  连接数据库工具类
    static ResourceBundle resourceBundle=null;
    static{
        resourceBundle= ResourceBundle.getBundle("sql");
    }
    public static String getSQL(String sqlkey){
        return resourceBundle.getString(sqlkey);
    }
}
