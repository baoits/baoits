/**
 * Created by IntelliJ IDEA.
 * User: lichee
 * Date: 2019-01-17
 * Time: 11:28
 * To change this template use File | Settings | File Templates.
 */
package top.baoit.tmall.j2ee.pojo;

public class PropertyPojo {
    private String name;
    private CategoryPojo categoryPojo;
    private Integer id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public CategoryPojo getCategoryPojo() {
        return categoryPojo;
    }

    public void setCategoryPojo(CategoryPojo categoryPojo) {
        this.categoryPojo = categoryPojo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
