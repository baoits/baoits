package top.baoit.tmall.j2ee.impl;

import top.baoit.tmall.j2ee.dao.CategoryDao;
import top.baoit.tmall.j2ee.pojo.CategoryPojo;
import top.baoit.tmall.j2ee.util.DaoUtil;

import java.util.List;

public class CategoryImpl extends DaoUtil implements CategoryDao {
    public int getCount() {
        return 0;
    }

    public int add(CategoryPojo categoryPojo) {
        return 0;
    }

    public int update(CategoryPojo categoryPojo) {
        return 0;
    }

    public int delete(Integer id) {
        return 0;
    }

    public CategoryPojo findByID(Integer id) {
        return null;
    }

    public List<CategoryPojo> list() {
        return null;
    }

    public List<CategoryPojo> list(Integer start, Integer count) {
        return null;
    }
}
