/**
 * Created by IntelliJ IDEA.
 * User: lichee
 * Date: 2019-01-17
 * Time: 11:28
 * To change this template use File | Settings | File Templates.
 */
package top.baoit.tmall.j2ee.pojo;

import java.util.Date;
import java.util.List;

public class ProductPojo {
    private String name;
    private String subTitle;
    private Double orignalPrice;
    private Double promotePrice;
    private Integer stock;
    private Date createDate;
    private CategoryPojo categoryPojo;
    private Integer id;
    private ProductImagePojo productImagePojo;
    private List<ProductImagePojo> productImagePojos;
    private List<ProductImagePojo> productSingImagePojos;
    private List<ProductImagePojo> productDetailImagePojos;
    private Integer reviewCount;
    private Integer saleCount;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    public Double getOrignalPrice() {
        return orignalPrice;
    }

    public void setOrignalPrice(Double orignalPrice) {
        this.orignalPrice = orignalPrice;
    }

    public Double getPromotePrice() {
        return promotePrice;
    }

    public void setPromotePrice(Double promotePrice) {
        this.promotePrice = promotePrice;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public CategoryPojo getCategoryPojo() {
        return categoryPojo;
    }

    public void setCategoryPojo(CategoryPojo categoryPojo) {
        this.categoryPojo = categoryPojo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public ProductImagePojo getProductImagePojo() {
        return productImagePojo;
    }

    public void setProductImagePojo(ProductImagePojo productImagePojo) {
        this.productImagePojo = productImagePojo;
    }

    public List<ProductImagePojo> getProductImagePojos() {
        return productImagePojos;
    }

    public void setProductImagePojos(List<ProductImagePojo> productImagePojos) {
        this.productImagePojos = productImagePojos;
    }

    public List<ProductImagePojo> getProductSingImagePojos() {
        return productSingImagePojos;
    }

    public void setProductSingImagePojos(List<ProductImagePojo> productSingImagePojos) {
        this.productSingImagePojos = productSingImagePojos;
    }

    public List<ProductImagePojo> getProductDetailImagePojos() {
        return productDetailImagePojos;
    }

    public void setProductDetailImagePojos(List<ProductImagePojo> productDetailImagePojos) {
        this.productDetailImagePojos = productDetailImagePojos;
    }

    public Integer getReviewCount() {
        return reviewCount;
    }

    public void setReviewCount(Integer reviewCount) {
        this.reviewCount = reviewCount;
    }

    public Integer getSaleCount() {
        return saleCount;
    }

    public void setSaleCount(Integer saleCount) {
        this.saleCount = saleCount;
    }
}
