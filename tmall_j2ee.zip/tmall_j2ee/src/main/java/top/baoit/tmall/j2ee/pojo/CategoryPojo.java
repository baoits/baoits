/**
 * Created by IntelliJ IDEA.
 * User: lichee
 * Date: 2019-01-17
 * Time: 11:28
 * To change this template use File | Settings | File Templates.
 */
package top.baoit.tmall.j2ee.pojo;

import java.util.List;

public class CategoryPojo {
    private Integer id;//
    private String name;//
    List<ProductPojo> productPojos;//
    List<List<ProductPojo>> productsByRow;//


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ProductPojo> getProductPojos() {
        return productPojos;
    }

    public void setProductPojos(List<ProductPojo> productPojos) {
        this.productPojos = productPojos;
    }

    public List<List<ProductPojo>> getProductsByRow() {
        return productsByRow;
    }

    public void setProductsByRow(List<List<ProductPojo>> productsByRow) {
        this.productsByRow = productsByRow;
    }


}
